#!/usr/bin/env python

import boto3
import gzip
from io import BytesIO
from time import sleep
from time import time

from config0_common.common import rm_rf
from config0_common.loggerly import Config0Logger
from config0_common.run_helper import EdReporter

class CheckBuild(EdReporter):

    def __init__(self,**kwargs):

        self.classname = "CheckBuild"

        self.logger = Config0Logger(self.classname)

        EdReporter.__init__(self,**kwargs)

        self.phase = "check_build"
        
        session = boto3.Session()
        self.codebuild_client = session.client('codebuild')
        self.s3 = boto3.resource('s3')

        self.build_id = kwargs.get("build_id")
        self.build_status = kwargs.get("build_status")
        self.artifacts = kwargs.get("artifacts")
        self.build_complete = kwargs.get("build_complete")
        self.build_start_time = kwargs.get("build_start_time")
        self.current_phase = kwargs.get("current_phase")
        self.build_source = kwargs.get("build_source")

        self.cdonly = True
        self.build_id_suffix = None
        self.codebuild_log = None

        self.run_t0 = int(time())
        self.run_maxtime = 800  # lambda maximum is 900

    def _set_order(self):

        human_description = 'Check build_id: "{}"'.format(self.build_id)
        inputargs = { "human_description":human_description }
        inputargs["role"] = "codebuild/build"
        self.new_order(**inputargs)

    def _set_build_status(self):

        if not self.build_status:
            buildStatus = self.codebuild_client.batch_get_builds(ids=[self.build_id])['builds'][0]['buildStatus']
        else:
            buildStatus = self.build_status

        print("codebuild status {}".format(buildStatus))

        if buildStatus == 'SUCCEEDED': 
            self.results["status"] = "successful"
            return True

        if buildStatus == 'FAILED': 
            self.results["status"] = "failed"
            return True

        if buildStatus == 'FAULT': 
            self.results["status"] = "failed"
            return True

        if buildStatus == 'STOPPED': 
            self.results["status"] = "failed"
            return True
        
        if buildStatus == 'TIMED_OUT': 
            self.results["status"] = "timed_out"
            return True

        return

    def _chk_build(self):

        _t1 = int(time())

        # see if build is done first
        build_done = self._set_build_status()

        status = None

        while True:

            if build_done: 
                break

            _time_elapsed = _t1 - self.run_t0

            # check if lambda function is about to expire
            if _time_elapsed > self.run_maxtime:
                self.logger.warn("lambda run max time exceeded {}".format(self.run_maxtimea))
                status = False
                break

            # check build exceeded total build time alloted
            if _t1 > self.build_expire:
                self.results["status"] = "timed_out"
                self.logger.warn("build timed out: after {} seconds.".format(str(self.build_timeout)))
                status = "timed_out"
                break

            sleep(5)
            build_done = self._set_build_status()

        self._loop_get_log()

        return status

    def _loop_get_log(self):

        maxtime = 30
        t0 = int(time())

        while True:

            _time_elapsed = int(time()) - t0

            if _time_elapsed > maxtime:
                self.logger.debug("time expired to retrieved log {} seconds".format(str(_time_elapsed)))
                return False

            self._get_log()
            if self.codebuild_log: break
            sleep(2)

    def _get_log(self):

        if self.codebuild_log: 
            return True

        try:
            _logname = "codebuild/logs/{}.gz".format(self.build_id_suffix)
            _dstfile = '/tmp/{}.gz'.format(self.build_id_suffix)

            self.logger.debug("retrieving log: s3://{}/{}".format(self.s3_bucket_tmp,_logname))

            self.s3.Bucket(self.s3_bucket_tmp).download_file(_logname,_dstfile)
            rm_rf(_dstfile)

            obj = self.s3.Object(self.s3_bucket_tmp,_logname)
            _read = obj.get()['Body'].read()
        except:
            self.logger.warn("FAIL: retrieving log: s3://{}/{}".format(self.s3_bucket_tmp,_logname))
            return 

        gzipfile = BytesIO(_read)
        gzipfile = gzip.GzipFile(fileobj=gzipfile)
        log = gzipfile.read().decode('utf-8')

        self.codebuild_log = log

        return log

    def _save_run_info(self):

        self.run_info["build_status"] = self.results["status"]
        self.table_runs.insert(self.run_info)

        msg = "trigger_id: {} saved".format(self.trigger_id)
        self.add_log(msg)

    def _get_build_summary(self):

        if self.results["status"] == "successful":
            summary_msg = "# Successful \n# trigger_id {} \n# build_id {}".format(self.trigger_id,self.build_id)
        elif self.results["status"] == "timed_out":
            summary_msg = "# Timed out \n# trigger_id {} \n# build_id {}".format(self.trigger_id,self.build_id)
        elif self.build_id is False:
            self.results["status"] = "failed"
            summary_msg = "# Never Triggered \n# trigger_id {}".format(self.trigger_id)
        elif self.build_id:
            self.results["status"] = "failed"
            summary_msg = "# Failed \n# trigger_id {} \n# build_id {}".format(self.trigger_id,self.build_id)
        else:
            self.results["status"] = "failed"
            summary_msg = "# Never Triggered \n# trigger_id {}".format(self.trigger_id)

        return summary_msg

    def execute(self):

        self.build_id = self.run_info["build_id"]
        self.build_expire = int(self.run_info["build_expire"])
        self.build_id_suffix = self.build_id.split(":")[1]

        status = self._chk_build()

        # did not get log yet
        # if false, lambda function 
        # will be timing out
        if status is False:
            self.results["update"] = None
            self.results["notify"] = None
            return True

        if status == "timed_out":
            self.results["update"] = True
            self.results["close"] = True
            self.results["notify"] = True
            _log = 'The build completely timed out'
        else:
            # the build is done at this point
            self.results["update"] = True
            self.results["close"] = True
            self.results["notify"] = True

        if not self.codebuild_log: 
            _log = 'Could not retrieved log for \nbuild_id "{}"'.format(self.build_id)
        else:
            _log = self.codebuild_log

        # we only set order once we are completely done
        self._set_order()

        self.add_log(_log)

        # at this point, the build finishes
        # either failed, timed_out, or successful
        summary_msg = self._get_build_summary()

        self.add_log("#"*32)
        self.add_log("# Summary")
        self.add_log(summary_msg)
        self.add_log("#"*32)

        self.results["msg"] = summary_msg
        self.results["notify"] = True

        self.finalize_order()
        self._save_run_info()

        return True
