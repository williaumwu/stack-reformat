#!/usr/bin/env python

from main_check_build import CheckBuild as Main
import json

def handler(event, context):

    try:
        event = json.loads(event)
    except:
        print("")
        print("event already a dictionary")
        print("")

    # this is sns trigger
    if "Records" in event:
        try:
            _message = json.loads(event['Records'][0]['Sns']['Message'])
        except:
            _message = event

        message = { "phase":"check_build" }
        message["build_status"] = _message["detail"]["build-status"]
        message["build_arn"] = _message["detail"]["build-id"]
        message["build_id"] = message["build_arn"].split("/")[-1]

        #message["build_complete"] = _message["detail"]["additional-information"]["build-complete"]
        #message["build_start_time"] = _message["detail"]["additional-information"]["build-start-time"]
        #message["current_phase"] = _message["detail"]["additional-information"]["current-phase"]
        #message["build_source"] = _message["detail"]["additional-information"]["source"]["location"]
        #message["artifacts"] = [ artifact["location"] for artifact in _message["detail"]["additional-information"]["artifact"] ]
    else:
        message = event

    print("")
    print(("message: " + json.dumps(message, indent=2)))
    print("")

    main = Main(**message)
    results = main.run()

    return { 'statusCode': 200,
             'body': json.dumps(results) }
