#!/usr/bin/env python

import json
import pickle
import zlib
import gzip
import base64

def b64_encode(obj):

    if not isinstance(obj,str):
        obj = json.dumps(obj)

    _bytes = obj.encode('ascii')
    base64_bytes = base64.b64encode(_bytes)

    # decode the b64 binary in a b64 string
    return base64_bytes.decode('ascii')

def b64_decode(token):

    base64_bytes = token.encode('ascii')
    _bytes = base64.b64decode(base64_bytes)

    try:
        _results = json.loads(_bytes.decode('ascii'))
    except:
        _results = _bytes.decode('ascii')

    return _results

def gz_pickle(fname, obj):
    return pickle.dump(obj=obj,file=gzip.open(fname,"wb",compresslevel=3),protocol=2)

def gz_upickle(fname):
    return pickle.load(gzip.open(fname,"rb"))

def zpickle(obj):
    return zlib.compress(pickle.dumps(obj,pickle.HIGHEST_PROTOCOL),9)

def z_unpickle(zstr):
    return pickle.loads(zlib.decompress(zstr))

def compress(indata):
    outdata = zlib.compress(indata,zlib.Z_BEST_COMPRESSION)
    return outdata

def uncompress(zdata):
    return zlib.decompress(zdata)  
