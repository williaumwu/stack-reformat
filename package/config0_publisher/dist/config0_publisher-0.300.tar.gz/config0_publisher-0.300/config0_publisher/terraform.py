#!/usr/bin/env python
#
#Project: config0_publisher: Config0 is a SaaS for building and managing
#software and DevOps automation. This particular packages is a python
#helper for publishing stacks, hostgroups, shellouts/scripts and other
#assets used for automation
#
#Examples include cloud infrastructure, CI/CD, and data analytics
#
#Copyright (C) Gary Leong - All Rights Reserved
#Unauthorized copying of this file, via any medium is strictly prohibited
#Proprietary and confidential
#Written by Gary Leong  <gary@config0.com, March 11,2023

import json
import os
from config0_publisher.utilities import print_json
from config0_publisher.loggerly import Config0Logger

class TFConstructor(object):

    def __init__(self,**kwargs):

        self.classname = 'TFConstructor'
        self.logger = Config0Logger(self.classname)
        self.logger.debug("Instantiating %s" % self.classname)

        self.stack = kwargs["stack"]
        self.provider = kwargs["provider"]
        self.execgroup_name = kwargs["execgroup_name"]
        self.resource_name = kwargs["resource_name"]
        self.resource_type = kwargs["resource_type"]
        self.terraform_type = kwargs["terraform_type"]
        self.docker_runtime = kwargs.get("docker_runtime")
        self.include_raw = kwargs.get("include_raw",True)

        self.include_keys = []
        self.output_keys = []
        self.output_prefix_key = None
        self.exclude_keys = []

        self.maps = {}

        self._init_opt_args()

        # for authoring purchasing, we use 
        # tag "db" instead of "resource_values"
        self.resource_values = self.stack.get_tagged_vars(tag="db",
                                                          output="dict")

    def _init_opt_args(self):

        include = []

        if not hasattr(self.stack,"docker_runtime") or not self.stack.docker_runtime:
            include.append("docker_runtime")
            if self.docker_runtime:
                self.stack.set_variable("docker_runtime",self.docker_runtime,types="str")
            else:
                self.stack.parse.add_required(key="docker_runtime",
                                              default="elasticdev/terraform-run-env:1.3.7",
                                              types="str")

        if not hasattr(self.stack,"remote_stateful_bucket"):
            include.append("remote_stateful_bucket")
            self.stack.parse.add_optional(key="remote_stateful_bucket",
                                          default="null",
                                          types="str,null")

        if not hasattr(self.stack,"cloud_tags_hash"):
            include.append("cloud_tags_hash")
            self.stack.parse.add_optional(key="cloud_tags_hash",
                                          default="null",
                                          types="str")

        if not hasattr(self.stack,"publish_to_saas"):
            include.append("publish_to_saas")
            self.stack.parse.add_optional(key="publish_to_saas",
                                          default="null",
                                          types="bool,null")

        if not hasattr(self.stack,"timeout"):
            include.append("timeout")
            self.stack.parse.add_optional(key="timeout",
                                          default=1800,
                                          types="int")

        self.stack.parse.tag_key(key="docker_runtime",
                                 tags="resource,db,execgroup_inputargs,docker")

        self.stack.parse.tag_key(key="remote_stateful_bucket",
                                 tags="resource,db,execgroup_inputargs,docker")

        self.stack.parse.tag_key(key="cloud_tags_hash",
                                 tags="execgroup_inputargs")

        self.stack.parse.tag_key(key="publish_to_saas",
                                 tags="execgroup_inputargs")

        self.stack.parse.tag_key(key="timeout",
                                 tags="execgroup_inputargs")

        self.stack.reset_variables(include=include)

    def _add_to_list(self,existing_keys,keys=None):

        if not keys:
            return

        for _key in keys:

            if _key in existing_keys:
                continue

            existing_keys.append(_key)

    def _add_to_dict(self,existing_values,values=None):

        if not values:
            return

        for _key,_value in values.items():

            if _key in existing_values:
                continue

            existing_values[_key] = _value

    def add_include_keys(self,keys=None):
        return self._add_to_list(self.include_keys,
                                 keys=keys)

    def add_exclude_keys(self,keys=None):
        return self._add_to_list(self.exclude_keys,
                                 keys=keys)

    def add_output_keys(self,keys=None):
        return self._add_to_list(self.output_keys,
                                 keys=keys)

    def add_resource_values(self,values=None):
        return self._add_to_dict(self.resource_values,
                                 values=values)

    def add_query_maps(self,maps=None):
        return self._add_to_dict(self.maps,
                                 values=maps)

    def include(self,keys=None,values=None,maps=None):

        if keys:
            self.add_include_keys(keys)
        elif values:
            self.add_resource_values(values)
        elif maps:
            self.add_query_maps(maps=maps)

    def output(self,keys,prefix_key=None):

        if prefix_key:
            self.output_prefix_key = prefix_key

        self.add_output_keys(keys)

    def exclude(self,keys):

        self.add_exclude_keys(keys)

    def get_resource_params(self):

        resource_params = { "include_raw": self.include_raw }

        if self.include_keys:
            resource_params["include_keys"] = self.include_keys

        if self.exclude_keys:
            resource_params["exclude_keys"] = self.exclude_keys

        if self.maps:
            resource_params["map_keys"] = self.maps

        return resource_params

    def _get_resource_settings(self):

        settings = {}

        env_vars = self.stack.get_tagged_vars(tag="resource",
                                              output="dict",
                                              uppercase=True)

        if self.resource_values:
            settings["resource_values_hash"] = self.stack.b64_encode(self.resource_values)

        if env_vars:
            settings["resource_env_vars_hash"] = self.stack.b64_encode(env_vars)

        if self.output_keys:
            settings["resource_output_keys_hash"] = self.stack.b64_encode(self.output_keys)

        if self.output_prefix_key:
            settings["resource_output_prefix"] = self.output_prefix_key

        return settings

    def _get_docker_settings(self):

        settings = {}

        # docker env vars during execution
        env_vars = self.stack.get_tagged_vars(tag="docker",
                                              output="dict",
                                              uppercase=True)

        if env_vars:
            settings["docker_env_vars_hash"] = self.stack.b64_encode(env_vars)

        return settings

    def _get_tf_settings(self):

        settings = {}

        # terraform variables converted to TF_VAR_<var>
        tf_vars = self.stack.get_tagged_vars(tag="tfvar",
                                             include_type=True,
                                             output="dict")

        if tf_vars:
            settings["tf_vars_hash"] = self.stack.b64_encode(tf_vars)

        resource_params = self.get_resource_params()

        if resource_params:
            settings["resource_params_hash"] = self.stack.b64_encode(resource_params)

        return settings

    def get_inputargs(self):

        self.stack.verify_variables()

        tf_settings = self._get_tf_settings()
        docker_settings = self._get_docker_settings()
        resource_settings = self._get_resource_settings()

        overide_values = self.stack.get_tagged_vars(tag="execgroup_inputargs",
                                                    output="dict")

        execgroup_ref = self.stack.get_locked(execgroup=self.execgroup_name)

        if not execgroup_ref:
            self.stack.logger.warn("execgroup_ref cannot be found through assets locks - will use the latest")
            execgroup_ref = self.execgroup_name

        overide_values["provider"] = self.provider
        overide_values["execgroup_ref"] = execgroup_ref
        overide_values["resource_name"] = self.resource_name
        overide_values["resource_type"] = self.resource_type
        overide_values["terraform_type"] = self.terraform_type

        # user provided overides
        if self.docker_runtime:
            overide_values["docker_runtime"] = self.docker_runtime

        self._add_to_dict(overide_values,tf_settings)
        self._add_to_dict(overide_values,docker_settings)
        self._add_to_dict(overide_values,resource_settings)

        inputargs = { "automation_phase": "infrastructure",
                      "human_description": "invoking tf executor",
                      "overide_values":overide_values }

        return inputargs

    def get(self):
        return self.get_inputargs()

###########################################################
# debugging purposes below but inserted into
# stack ed_core -> tf_executor for versioning and such
###########################################################

class DockerSettings(object):

    def __init__(self,**kwargs):

        self.stack = kwargs["stack"]
        self.runtime = kwargs["docker_runtime"]

        if kwargs.get("docker_env_vars"):
            self.env_vars = kwargs["docker_env_vars"]
            self.to_env_var_value()
        else:
            self.env_vars = {}

        self.env_vars["STATEFUL_ID"] = self.stack.stateful_id

        self.settings = { "env_vars":self.env_vars }

    def to_env_var_value(self):

        if not self.env_vars.items():
            return

        for _key,_value in self.env_vars.items():

            try:
                number_value = int(_value)
            except:
                number_value = None

            if number_value:
                self.env_vars[_key] = "{}".format(_value)
                continue

            if _value is True:
                self.env_vars[_key] = "True"
            elif _value is False:
                self.env_vars[_key] = "False"
            elif _value is None:
                self.env_vars[_key] = "None"

    def insert_env_vars(self,env_vars):

        if not env_vars:
            return

        for _key,_value in env_vars.items():

            if _key in self.env_vars:
                continue

            self.env_vars[_key] = _value

        self.to_env_var_value()

class ResourceSettings(object):

    def __init__(self,**kwargs):

        self.stack = kwargs["stack"]

        # set additional vars
        self.provider = kwargs["provider"]
        self.type = kwargs["resource_type"]
        self.name = kwargs["resource_name"]
        self.tf_vars = kwargs.get("tf_vars")

        if kwargs.get("resource_output_keys"):
            self.output_keys = kwargs["resource_output_keys"]

            self.output_keys.extend( [ "remote_stateful_location",
                                       "docker_runtime" ] )

        else:
            self.output_keys = []

        if kwargs.get("resource_prefix_key"):
            self.output_prefix_key = kwargs["resource_output_prefix_key"]
        else:
            self.output_prefix_key = self.name

        if kwargs.get("resource_values"):
            self.values = kwargs["resource_values"]
        else:
            self.values = {}

        if kwargs.get("resource_env_vars"):
            self.env_vars = kwargs["resource_env_vars"]
            self.to_env_var_value()
        else:
            self.env_vars = {}

        self.docker = DockerSettings(**kwargs)

        self._set_base_values()

    def to_env_var_value(self):

        if not self.env_vars.items():
            return

        for _key,_value in self.env_vars.items():

            if _value is True:
                self.env_vars[_key] = "True"
            elif _value is False:
                self.env_vars[_key] = "False"
            elif _value is None:
                self.env_vars[_key] = "None"

    def insert_env_vars(self,env_vars):

        if not env_vars:
            return

        for _key,_value in env_vars.items():

            if _key in self.env_vars:
                continue

            self.env_vars[_key] = _value

        self.to_env_var_value()

    def _set_base_values(self):

        # this env vars is for the stack and execgroup execution
        # we need to specify create which will then
        # pass it to the docker container

        self.env_vars["METHOD"] = "create"
        self.env_vars["STATEFUL_ID"] = self.stack.stateful_id

        self.values["resource_type"] = self.type
        self.values["name"] = self.name
        self.values["provider"] = self.provider
        self.values["docker_runtime"] = self.docker.runtime

    def set_aws(self):

        self.docker.settings["include_env_vars_keys"] = [ "aws_access_key_id",
                                                          "aws_secret_access_key" ]

        self.docker.settings["env_vars"]["RESOURCE_TAGS"] = "{},{}".format(self.type, 
                                                                           self.name)

    def set_do(self):

        self.docker.settings["include_env_vars_keys"] = [ "digitalocean_access_token", 
                                                          "digitalocean_token",
                                                          "do_token" ]

        self.docker.settings["env_vars"]["RESOURCE_TAGS"] = "{},{}".format(self.type, 
                                                                           self.name)

        if self.values.get("region") and not self.env_vars.get("DO_REGION"):
            self.env_vars["DO_REGION"] = self.values["region"]

    def get_inputargs(self,env_vars=None):

        if env_vars:
            self.insert_env_vars(env_vars)
        
        inputargs = {"display":True}
        inputargs["env_vars"] = json.dumps(self.env_vars)
        inputargs["name"] = self.name
        inputargs["human_description"] = "Creating name {} type {}".format(self.name,
                                                                           self.type)
        inputargs["stateful_id"] = self.stack.stateful_id

        if hasattr(self.stack,"remote_stateful_bucket") and self.stack.remote_stateful_bucket not in ["null", None]:
            inputargs["remote_stateful_bucket"] = self.stack.remote_stateful_bucket

        if hasattr(self.stack,"timeout") and self.stack.timeout:
            inputargs["timeout"] = self.stack.timeout

        inputargs["display_hash"] = self.stack.get_hash_object(inputargs)

        return inputargs

    def get_output_inputargs(self):

        if not self.output_keys:
            return

        overide_values = { "name":self.name,
                           "resource_type":self.type,
                           "ref_schedule_id":self.stack.schedule_id,
                           "publish_keys_hash":self.stack.b64_encode(self.output_keys) }

        if self.output_prefix_key:
            overide_values["prefix_key"] = self.output_prefix_key

        inputargs = { "overide_values":overide_values }

        inputargs["automation_phase"] = "infrastructure"

        inputargs["human_description"] = 'Output resource name "{}" type "{}"'.format(self.name,
                                                                                      self.type)

        return inputargs
